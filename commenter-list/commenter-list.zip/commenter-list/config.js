// コメントした人リスト（わんコメ用テンプレート） Copyright (c) 2026 Retzn. All rights reserved.
// わんコメ（OneComme）に感謝を込めて — https://onecomme.com/
// ===== 設定ファイル（メモ帳で編集できます）=====
window.CLIST_CONFIG = {
  // 配信者本人（自分のコメント）をリストに入れる（true / false）
  includeOwner: false,

  // 最後のコメントからこの時間（時間単位）空いたら、次のコメントで自動リセット
  // （＝次の配信では自動で新しいリストになる）。0 で自動リセットしない
  autoResetHours: 4,

  // わんコメの「コメントクリア」でリストもリセットする（true / false）
  resetOnClear: true,

  // ニックネーム手動指定（わんコメのコテハン機能より優先）
  // 左側は YouTubeの「@ハンドル名」か表示名
  nicknames: {
    // "@example_handle": "れいくん",
  },
};
